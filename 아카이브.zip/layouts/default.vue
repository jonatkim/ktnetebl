<template>
  <VApp class="ktnet-app">
    <AppHeader />

    <VMain>
      <VContainer fluid class="ktnet-page">
        <slot />
      </VContainer>
    </VMain>
  </VApp>
</template>

<script setup>
import AppHeader from '@/components/layout/AppHeader.vue'
</script>