<template>
  <section>
    <h1 class="kt-title">
      KTNET · UI Starter
    </h1>

    <p class="kt-subtitle">
      Nuxt 3 + Vuetify 3 + AG Grid + SCSS 기본 셋업입니다.
    </p>

    <VRow class="mt-6" justify="start" align="stretch" dense>
      <VCol cols="12" md="6" lg="4">
        <VCard>
          <VCardTitle>레이아웃</VCardTitle>
          <VCardText>
            상단 AppBar + VMain + VContainer 기본 구조가 적용되어 있습니다.
          </VCardText>
        </VCard>
      </VCol>

      <VCol cols="12" md="6" lg="4">
        <VCard>
          <VCardTitle>데이터 그리드</VCardTitle>
          <VCardText>
            Lab · Table 페이지에서 AG Grid 샘플을 확인할 수 있습니다.
          </VCardText>
          <VCardActions>
            <VBtn color="primary" variant="text" to="/publish/sample/table">
              Go to Table Lab
            </VBtn>
          </VCardActions>
        </VCard>
      </VCol>

      <VCol cols="12" md="6" lg="4">
        <VCard>
          <VCardTitle>스타일</VCardTitle>
          <VCardText>
            assets/styles 아래에서 토큰과 전역 스타일을 관리합니다.
          </VCardText>
        </VCard>
      </VCol>
    </VRow>
  </section>
</template>

<script setup>
</script>

<style scoped lang="scss">
.kt-title {
  font-size: 1.75rem;
  font-weight: 700;
}

.kt-subtitle {
  margin-top: 0.5rem;
  color: #4b5563;
}
</style>