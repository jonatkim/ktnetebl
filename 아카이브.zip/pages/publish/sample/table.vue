<template>
  <section>
    <h1 class="mb-4">KTNET · Data Grid Lab</h1>

    <p class="mb-4">기본 정렬/필터/리사이즈가 적용된 AG Grid 샘플입니다.</p>

    <KtDataGrid
      :row-data="rowData"
      :column-defs="columnDefs"
      :default-col-def="{ minWidth: 120 }"
      grid-height="420px"
      :row-selection="{ mode: 'multiRow' }"
    />
  </section>
</template>

<script setup>
import { ref } from 'vue'
import KtDataGrid from '@/components/grid/KtDataGrid.vue'

const rowData = ref([
  { id: 1, name: '홍길동', age: 32, city: 'Seoul' },
  { id: 2, name: 'Jane', age: 28, city: 'Busan' },
  { id: 3, name: 'Ken', age: 41, city: 'Incheon' },
])

const columnDefs = ref([
  { field: 'id', headerName: 'ID' },
  { field: 'name', headerName: '이름' },
  { field: 'age', headerName: '나이' },
  { field: 'city', headerName: '도시' },
])
</script>

<style scoped>
.mb-4 {
  margin-bottom: 1rem;
}
</style>
