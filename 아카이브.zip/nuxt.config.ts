import { defineNuxtConfig } from 'nuxt/config'
import vuetify from 'vite-plugin-vuetify'

export default defineNuxtConfig({
  compatibilityDate: '2025-12-02',
  css: [
    'vuetify/styles',
    'ag-grid-community/styles/ag-theme-quartz.css',
    '@/assets/styles/main.scss',
  ],
  devServer: {
    host: '0.0.0.0',
    port: 3000
  },

  build: {
    transpile: ['vuetify'],
  },

  vite: {
    plugins: [
      vuetify({
        autoImport: true,
      }),
    ],
    define: {
      'process.env.DEBUG': false,
    },
    ssr: {
      noExternal: ['vuetify'],
    },
  },
})