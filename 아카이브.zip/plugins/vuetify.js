import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'

export default defineNuxtPlugin((nuxtApp) => {
  const vuetify = createVuetify({
    ssr: true,
    components,
    directives,
    theme: {
      defaultTheme: 'ktnetLight',
      themes: {
        ktnetLight: {
          dark: false,
          colors: {
            primary: '#2563eb',
            secondary: '#64748b',
            surface: '#ffffff',
            background: '#f9fafb',
            error: '#ef4444',
          },
        },
      },
    },
  })

  nuxtApp.vueApp.use(vuetify)
})