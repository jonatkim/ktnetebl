<template>
  <div class="kt-grid ag-theme-quartz" :style="{ height: gridHeight }">
    <AgGridVue
      class="kt-grid__inner"
      :rowData="rowData"
      :columnDefs="columnDefs"
      :defaultColDef="mergedDefaultColDef"
      :pagination="pagination"
      :paginationPageSize="paginationPageSize"
      :rowSelection="rowSelection"
      @grid-ready="onGridReady"
    />
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { AgGridVue } from 'ag-grid-vue3'

const props = defineProps({
  rowData: {
    type: Array,
    default: () => [],
  },
  columnDefs: {
    type: Array,
    default: () => [],
  },
  defaultColDef: {
    type: Object,
    default: () => ({}),
  },
  gridHeight: {
    type: String,
    default: '400px',
  },
  pagination: {
    type: Boolean,
    default: true,
  },
  paginationPageSize: {
    type: Number,
    default: 20,
  },
  rowSelection: {
    type: Object,
    default: () => ({
      mode: 'singleRow',
    }),
  },
})

const gridApi = ref(null)
const columnApi = ref(null)

const baseDefaultColDef = {
  sortable: true,
  filter: true,
  resizable: true,
}

const mergedDefaultColDef = computed(() => ({
  ...baseDefaultColDef,
  ...props.defaultColDef,
}))

function onGridReady(params) {
  gridApi.value = params.api
  columnApi.value = params.columnApi
  params.api.sizeColumnsToFit()
}
</script>

<style scoped lang="scss">
.kt-grid {
  width: 100%;

  &__inner {
    width: 100%;
    height: 100%;
  }
}
</style>
