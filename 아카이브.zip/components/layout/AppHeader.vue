<template>
  <VAppBar color="primary" density="comfortable" flat>
    <VAppBarTitle>
      KTNET
    </VAppBarTitle>

    <VSpacer />

    <VBtn variant="text" to="/" class="text-none">
      Home
    </VBtn>
    <VBtn variant="text" to="/publish/sample/table" class="text-none">
      Lab · Table
    </VBtn>
  </VAppBar>
</template>

<script setup>
</script>

<style scoped>
.text-none {
  text-transform: none;
}
</style>